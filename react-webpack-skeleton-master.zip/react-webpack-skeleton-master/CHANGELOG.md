## [v1.0.2]
> July 28th, 2016

- EditableSelect demo
- Add Gmap Component/demo
- Add blue-text demo
- Add React Autosuggest Search Bar
- Add additional icons on sidebar
- Neaten up Breadcrumbs (use render functions instead)
- Update to latest version of Blur v0.10.0

## [v1.0.1]
> June 15th, 2016

- Add Alert Bar demo
- Add Breadcrumbs

## [v1.0.0]
> May 23rd, 2016

- Initial Demo


